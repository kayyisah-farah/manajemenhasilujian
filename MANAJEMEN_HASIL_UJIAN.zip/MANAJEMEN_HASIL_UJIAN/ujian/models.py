from django.db import models
from django.contrib.auth.models import AbstractUser
from django.conf import settings

# === Custom User Model ===
class User(AbstractUser):
    ROLE_CHOICES = (
        ('admin', 'Admin'),
        ('dosen', 'Dosen'),
    )
    role = models.CharField(max_length=10, choices=ROLE_CHOICES)
    nama_dosen = models.CharField("Nama Dosen", max_length=100, blank=True, null=True)

    def __str__(self):
        return f"{self.username} ({self.role})"

    class Meta:
        verbose_name = "Pengguna"
        verbose_name_plural = "Pengguna"


# === Mahasiswa ===
class Mahasiswa(models.Model):
    nim = models.CharField("NIM", max_length=20, unique=True)
    nama = models.CharField("Nama Lengkap", max_length=100)
    program_studi = models.CharField("Program Studi", max_length=100, null=True, blank=True)
    email = models.EmailField("Email")

    def __str__(self):
        return f"{self.nim} - {self.nama}"

    class Meta:
        verbose_name = "Mahasiswa"
        verbose_name_plural = "Mahasiswa"


# === Mata Kuliah ===
class MataKuliah(models.Model):
    kode = models.CharField("Kode MK", max_length=10, unique=True)
    nama_mata_kuliah = models.CharField("Nama Mata Kuliah", max_length=100)
    sks = models.PositiveIntegerField("Jumlah SKS")

    def __str__(self):
        return f"{self.kode} - {self.nama_mata_kuliah}"

    class Meta:
        verbose_name = "Mata Kuliah"
        verbose_name_plural = "Mata Kuliah"


# === Relasi Dosen dan Mata Kuliah ===
class DosenMataKuliah(models.Model):
    dosen = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        limit_choices_to={'role': 'dosen'},
        verbose_name="Dosen Pengampu"
    )
    mata_kuliah = models.ForeignKey(
        MataKuliah,
        on_delete=models.CASCADE,
        verbose_name="Mata Kuliah"
    )

    def __str__(self):
        return f"{self.dosen.nama_dosen or self.dosen.username} - {self.mata_kuliah.nama_mata_kuliah}"

    class Meta:
        verbose_name = "Pengampu"
        verbose_name_plural = "Pengampu Mata Kuliah"


# === Nilai Mahasiswa ===
class Nilai(models.Model):
    mahasiswa = models.ForeignKey(Mahasiswa, on_delete=models.CASCADE, verbose_name="Mahasiswa")
    mata_kuliah = models.ForeignKey(MataKuliah, on_delete=models.CASCADE, verbose_name="Mata Kuliah")
    dosen = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        limit_choices_to={'role': 'dosen'},
        verbose_name="Dosen Penilai"
    )
    nilai = models.DecimalField("Nilai", max_digits=5, decimal_places=2)

    def __str__(self):
        return f"{self.mahasiswa.nama} - {self.mata_kuliah.nama_mata_kuliah} = {self.nilai}"

    class Meta:
        verbose_name = "Nilai"
        verbose_name_plural = "Data Nilai"
