from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.db.models import Q
from .models import User, Mahasiswa, MataKuliah, DosenMataKuliah, Nilai
from .forms import (DosenForm, EditDosenForm, MahasiswaForm, MataKuliahForm, DosenMataKuliahForm)

# LOGIN & LOGOUT 
def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            if user.role == 'admin':
                return redirect('dashboard')
            elif user.role == 'dosen':
                return redirect('dosen_dashboard')
        else:
            return render(request, 'login.html', {'error': 'Username atau password salah'})
    return render(request, 'login.html')


def logout_view(request):
    logout(request)
    return redirect('login')


# CEK ROLE 
def is_admin(user):
    return user.is_authenticated and user.role == 'admin'


def is_dosen(user):
    return user.is_authenticated and user.role == 'dosen'

# DASHBOARD 
@login_required
def dashboard(request):
    if request.user.role == 'admin':
        context = {
            'total_mahasiswa': Mahasiswa.objects.count(),
            'total_dosen': User.objects.filter(role='dosen').count(),
            'total_matkul': MataKuliah.objects.count(),
            'total_nilai': Nilai.objects.count(),
            'total_pengampu': DosenMataKuliah.objects.count(),
        }
        return render(request, 'admin/admin_dashboard.html', context)
    elif request.user.role == 'dosen':
        return redirect('dosen_dashboard')
    else:
        return redirect('logout')


@user_passes_test(is_dosen)
def dosen_dashboard(request):
    return render(request, 'dosen/dosen_dashboard.html')


# MANAJEMEN DOSEN 
@user_passes_test(is_admin)
def dosen_list(request):
    query = request.GET.get('q')
    if query:
        dosen = User.objects.filter(
            Q(role='dosen') & (
                Q(username__icontains=query) |
                Q(first_name__icontains=query) |
                Q(last_name__icontains=query) |
                Q(email__icontains=query)
            )
        )
    else:
        dosen = User.objects.filter(role='dosen')
    return render(request, 'admin/dosen_list.html', {'dosen': dosen})


@user_passes_test(is_admin)
def dosen_create(request):
    """
    Tambah akun dosen baru (admin saja).
    Memerlukan password awal.
    """
    if request.method == 'POST':
        form = DosenForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.role = 'dosen'  
            user.save()
            return redirect('dosen_list')
    else:
        form = DosenForm()
    return render(request, 'admin/dosen_form.html', {
        'form': form,
        'title': 'Tambah Dosen',
        'mode': 'create',   
    })


@user_passes_test(is_admin)
def dosen_edit(request, pk):
    """
    Edit data dosen: hanya username, nama_dosen (first_name), email.
    Tidak mengubah password.
    """
    dosen = get_object_or_404(User, pk=pk)

    if request.method == 'POST':
        form = EditDosenForm(request.POST, instance=dosen)
        if form.is_valid():
            user = form.save(commit=False)
            user.role = 'dosen'  
            user.save()
            return redirect('dosen_list')
    else:
        form = EditDosenForm(instance=dosen)

    return render(request, 'admin/dosen_form.html', {
        'form': form,
        'title': 'Edit Dosen',
        'mode': 'edit',     
    })


@user_passes_test(is_admin)
def dosen_delete(request, pk):
    dosen = get_object_or_404(User, pk=pk)
    dosen.delete()
    return redirect('dosen_list')


# MANAJEMEN MAHASISWA 
@user_passes_test(is_admin)
def mahasiswa_list(request):
    mahasiswa = Mahasiswa.objects.all()
    return render(request, 'admin/mahasiswa_list.html', {'mahasiswa': mahasiswa})


@user_passes_test(is_admin)
def mahasiswa_create(request):
    if request.method == 'POST':
        form = MahasiswaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('mahasiswa_list')
    else:
        form = MahasiswaForm()
    return render(request, 'admin/mahasiswa_form.html', {'form': form, 'title': 'Tambah Mahasiswa'})


@user_passes_test(is_admin)
def mahasiswa_edit(request, pk):
    mhs = get_object_or_404(Mahasiswa, pk=pk)
    if request.method == 'POST':
        form = MahasiswaForm(request.POST, instance=mhs)
        if form.is_valid():
            form.save()
            return redirect('mahasiswa_list')
    else:
        form = MahasiswaForm(instance=mhs)
    return render(request, 'admin/mahasiswa_form.html', {'form': form, 'title': 'Edit Mahasiswa'})


@user_passes_test(is_admin)
def mahasiswa_delete(request, pk):
    mhs = get_object_or_404(Mahasiswa, pk=pk)
    mhs.delete()
    return redirect('mahasiswa_list')


# MANAJEMEN MATA KULIAH
@user_passes_test(is_admin)
def mata_kuliah_list(request):
    mata_kuliah = MataKuliah.objects.all()
    return render(request, 'admin/mata_kuliah_list.html', {'mata_kuliah': mata_kuliah})


@user_passes_test(is_admin)
def mata_kuliah_create(request):
    if request.method == 'POST':
        form = MataKuliahForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('mata_kuliah_list')
    else:
        form = MataKuliahForm()
    return render(request, 'admin/mata_kuliah_form.html', {'form': form, 'title': 'Tambah Mata Kuliah'})


@user_passes_test(is_admin)
def mata_kuliah_edit(request, pk):
    mk = get_object_or_404(MataKuliah, pk=pk)
    if request.method == 'POST':
        form = MataKuliahForm(request.POST, instance=mk)
        if form.is_valid():
            form.save()
            return redirect('mata_kuliah_list')
    else:
        form = MataKuliahForm(instance=mk)
    return render(request, 'admin/mata_kuliah_form.html', {'form': form, 'title': 'Edit Mata Kuliah'})


@user_passes_test(is_admin)
def mata_kuliah_delete(request, pk):
    mk = get_object_or_404(MataKuliah, pk=pk)
    mk.delete()
    return redirect('mata_kuliah_list')


# MANAJEMEN PENGAMPU
@user_passes_test(is_admin)
def pengampu_list(request):
    pengampu = DosenMataKuliah.objects.all()
    return render(request, 'admin/pengampu_list.html', {'pengampu': pengampu})


@user_passes_test(is_admin)
def pengampu_create(request):
    if request.method == 'POST':
        form = DosenMataKuliahForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('pengampu_list')
    else:
        form = DosenMataKuliahForm()
    return render(request, 'admin/pengampu_form.html', {'form': form, 'title': 'Tambah Pengampu'})


@user_passes_test(is_admin)
def pengampu_edit(request, pk):
    pengampu = get_object_or_404(DosenMataKuliah, pk=pk)
    if request.method == 'POST':
        form = DosenMataKuliahForm(request.POST, instance=pengampu)
        if form.is_valid():
            form.save()
            return redirect('pengampu_list')
    else:
        form = DosenMataKuliahForm(instance=pengampu)
    return render(request, 'admin/pengampu_form.html', {'form': form, 'title': 'Edit Pengampu'})


@user_passes_test(is_admin)
def pengampu_delete(request, pk):
    p = get_object_or_404(DosenMataKuliah, pk=pk)
    p.delete()
    return redirect('pengampu_list')


# INPUT NILAI (DOSEN)
@user_passes_test(is_dosen)
def input_nilai_dosen(request):
    # Ambil mata kuliah yang diajar dosen ini
    pengampu = DosenMataKuliah.objects.filter(dosen=request.user)
    matkul_ids = pengampu.values_list('mata_kuliah__id', flat=True)
    mata_kuliah = MataKuliah.objects.filter(id__in=matkul_ids)

    # Ambil semua mahasiswa
    mahasiswa_all = Mahasiswa.objects.all()

    if request.method == 'POST':
        mhs_id = request.POST.get('mahasiswa')
        mk_id = request.POST.get('mata_kuliah')
        tugas = request.POST.get('tugas')
        uts = request.POST.get('uts')
        uas = request.POST.get('uas')

        if mhs_id and mk_id and tugas and uts and uas:
            mhs = get_object_or_404(Mahasiswa, pk=mhs_id)
            mk = get_object_or_404(MataKuliah, pk=mk_id)

            # Hitung nilai akhir
            nilai_akhir = round((float(tugas) * 0.3) + (float(uts) * 0.3) + (float(uas) * 0.4), 2)

            # Simpan atau update nilai
            Nilai.objects.update_or_create(
                mahasiswa=mhs,
                mata_kuliah=mk,
                dosen=request.user,
                defaults={'nilai': nilai_akhir}
            )

            # Redirect ke halaman rekap nilai dengan mata kuliah yang sama
            from django.urls import reverse
            return redirect(f"{reverse('rekap_nilai_dosen')}?mata_kuliah={mk.id}")

    return render(request, 'dosen/input_nilai.html', {
        'mata_kuliah': mata_kuliah,
        'mahasiswa': mahasiswa_all,
    })

@login_required
@user_passes_test(is_dosen)
def dosen_mata_kuliah_list(request):
    # Tampilkan hanya mata kuliah yang diampu dosen
    pengampu = DosenMataKuliah.objects.filter(dosen=request.user)
    mata_kuliah = MataKuliah.objects.filter(id__in=pengampu.values_list('mata_kuliah', flat=True))
    return render(request, 'dosen/mata_kuliah_list.html', {'mata_kuliah': mata_kuliah})

@login_required
@user_passes_test(is_dosen)
def dosen_mahasiswa_list(request):
    # Jika ingin dibatasi ke mahasiswa yang pernah dinilai, gunakan filter.
    mahasiswa = Mahasiswa.objects.all()
    return render(request, 'dosen/mahasiswa_list.html', {'mahasiswa': mahasiswa})

# REKAP NILAI (DOSEN) 
@user_passes_test(is_dosen)
def rekap_nilai_dosen(request):
    # Cek user login sebagai dosen
    pengampu = DosenMataKuliah.objects.filter(dosen=request.user)

    # DEBUG: cek apakah query ini mengembalikan hasil
    print("Pengampu ditemukan:", pengampu.exists())

    matkul_ids = pengampu.values_list('mata_kuliah__id', flat=True)
    mata_kuliah = MataKuliah.objects.filter(id__in=matkul_ids)

    selected_matkul_id = request.GET.get('mata_kuliah')
    nilai_list = []

    if selected_matkul_id:
        nilai_list = Nilai.objects.filter(
            mata_kuliah_id=selected_matkul_id,
            dosen=request.user
        ).select_related('mahasiswa')

    return render(request, 'dosen/rekap_nilai.html', {
        'mata_kuliah': mata_kuliah,
        'nilai_list': nilai_list,
        'selected_matkul_id': selected_matkul_id,
    })
