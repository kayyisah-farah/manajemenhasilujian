from django.urls import path
from . import views

urlpatterns = [
    # === Auth ===
    path('', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    # === Dashboard ===
    path('dashboard/', views.dashboard, name='dashboard'),
    path('dashboard/dosen/', views.dosen_dashboard, name='dosen_dashboard'),

    # === Admin: Dosen ===
    path('panel-admin/dosen/', views.dosen_list, name='dosen_list'),
    path('panel-admin/dosen/tambah/', views.dosen_create, name='dosen_create'),
    path('panel-admin/dosen/edit/<int:pk>/', views.dosen_edit, name='dosen_edit'),
    path('panel-admin/dosen/hapus/<int:pk>/', views.dosen_delete, name='dosen_delete'),

    # === Admin: Mahasiswa ===
    path('panel-admin/mahasiswa/', views.mahasiswa_list, name='mahasiswa_list'),
    path('panel-admin/mahasiswa/tambah/', views.mahasiswa_create, name='mahasiswa_create'),
    path('panel-admin/mahasiswa/edit/<int:pk>/', views.mahasiswa_edit, name='mahasiswa_edit'),
    path('panel-admin/mahasiswa/hapus/<int:pk>/', views.mahasiswa_delete, name='mahasiswa_delete'),

    # === Admin: Mata Kuliah ===
    path('panel-admin/mata-kuliah/', views.mata_kuliah_list, name='mata_kuliah_list'),
    path('panel-admin/mata-kuliah/tambah/', views.mata_kuliah_create, name='mata_kuliah_create'),
    path('panel-admin/mata-kuliah/edit/<int:pk>/', views.mata_kuliah_edit, name='mata_kuliah_edit'),
    path('panel-admin/mata-kuliah/hapus/<int:pk>/', views.mata_kuliah_delete, name='mata_kuliah_delete'),

    # === Admin: Pengampu ===
    path('panel-admin/pengampu/', views.pengampu_list, name='pengampu_list'),
    path('panel-admin/pengampu/tambah/', views.pengampu_create, name='pengampu_create'),
    path('panel-admin/pengampu/edit/<int:pk>/', views.pengampu_edit, name='pengampu_edit'),
    path('panel-admin/pengampu/hapus/<int:pk>/', views.pengampu_delete, name='pengampu_delete'),

    # === Dosen ===
    path('panel-dosen/input-nilai/', views.input_nilai_dosen, name='input_nilai_dosen'),
    path('panel-dosen/rekap-nilai/', views.rekap_nilai_dosen, name='rekap_nilai_dosen'),
    path('dosen/mahasiswa/', views.dosen_mahasiswa_list, name='dosen_mahasiswa_list'),
    path('dosen/matakuliah/', views.dosen_mata_kuliah_list, name='dosen_mata_kuliah_list'),
]
