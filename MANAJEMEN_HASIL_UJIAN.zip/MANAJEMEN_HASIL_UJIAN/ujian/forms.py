from django import forms
from .models import User, Mahasiswa, MataKuliah, DosenMataKuliah

# =====================
# FORM TAMBAH DOSEN
# =====================
class DosenForm(forms.ModelForm):
    username = forms.CharField(
        label='Username',
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    nama_dosen = forms.CharField(
        label='Nama Dosen',
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    email = forms.EmailField(
        label='Email',
        widget=forms.EmailInput(attrs={'class': 'form-control'})
    )
    password = forms.CharField(
        label='Password',
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
    )

    class Meta:
        model = User
        fields = ['username', 'email', 'password']  # 'nama_dosen' disimpan ke first_name

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password'])  # Enkripsi password
        user.first_name = self.cleaned_data['nama_dosen']
        user.role = 'dosen'
        if commit:
            user.save()
        return user

# =====================
# FORM EDIT DOSEN
# =====================
class EditDosenForm(forms.ModelForm):
    username = forms.CharField(
        label='Username',
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    nama_dosen = forms.CharField(
        label='Nama Dosen',
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    email = forms.EmailField(
        label='Email',
        widget=forms.EmailInput(attrs={'class': 'form-control'})
    )

    class Meta:
        model = User
        fields = ['username', 'email']  # Tidak ada password

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Set nilai awal 'nama_dosen' dari first_name
        if self.instance:
            self.fields['nama_dosen'].initial = self.instance.first_name

    def save(self, commit=True):
        user = super().save(commit=False)
        user.first_name = self.cleaned_data['nama_dosen']  # Simpan nama dosen ke first_name
        if commit:
            user.save()
        return user

# =====================
# FORM MAHASISWA
# =====================
class MahasiswaForm(forms.ModelForm):
    class Meta:
        model = Mahasiswa
        fields = ['nim', 'nama', 'program_studi', 'email']
        widgets = {
            'nim': forms.TextInput(attrs={'class': 'form-control'}),
            'nama': forms.TextInput(attrs={'class': 'form-control'}),
            'program_studi': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
        }

# =====================
# FORM MATA KULIAH
# =====================
class MataKuliahForm(forms.ModelForm):
    class Meta:
        model = MataKuliah
        fields = ['kode', 'nama_mata_kuliah', 'sks']
        widgets = {
            'kode': forms.TextInput(attrs={'class': 'form-control'}),
            'nama_mata_kuliah': forms.TextInput(attrs={'class': 'form-control'}),
            'sks': forms.NumberInput(attrs={'class': 'form-control'}),
        }

# =====================
# FORM DOSEN-MATA KULIAH
# =====================
class DosenMataKuliahForm(forms.ModelForm):
    class Meta:
        model = DosenMataKuliah
        fields = ['dosen', 'mata_kuliah']
        widgets = {
            'dosen': forms.Select(attrs={'class': 'form-control'}),
            'mata_kuliah': forms.Select(attrs={'class': 'form-control'}),
        }
